// Vercel API endpoint
import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';
import admin from 'firebase-admin';

// Firebase Admin initialization
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(),
    projectId: process.env.FIREBASE_PROJECT_ID || 'zaman-9903a'
  });
}

const db = admin.firestore();
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    if (req.method === 'GET') {
      const snapshot = await db.collection('simulations').orderBy('createdAt', 'desc').get();
      const simulations = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      return res.json(simulations);
    }

    if (req.method === 'POST') {
      const simulation = req.body;
      
      // AI prompt generation
      const prompt = `Sen bir hayat koçu ve kişisel danışmansın. Aşağıdaki kişi için alternatif hayat senaryosu analiz et:

KİŞİ BİLGİLERİ:
- Yaş: ${simulation.age}
- Meslek: ${simulation.occupation}
- Şehir: ${simulation.location}
- Medeni durum: ${simulation.maritalStatus}
- Gelir seviyesi: ${simulation.incomeLevel}

MEVCUT DURUM: ${simulation.currentSituation}
HEDEFLERİ: ${simulation.goals}
ALTERNATİF KARAR: ${simulation.alternativeChoice}

Bu kişi için ${simulation.alternativeChoice} kararını verdiğini düşünerek, bu karar sonucu hayatının nasıl şekillenebileceğini analiz et.

Yanıtını JSON formatında ver:
{
  "timeframe": "X yıl sonra",
  "scenario": "Ana senaryo açıklaması",
  "positiveOutcomes": ["olumlu sonuç 1", "olumlu sonuç 2"],
  "challenges": ["zorluk 1", "zorluk 2"],
  "financialImpact": "Mali durum analizi",
  "personalGrowth": "Kişisel gelişim analizi",
  "relationships": "İlişkiler üzerindeki etkisi",
  "recommendation": "Genel tavsiye"
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          responseMimeType: "application/json",
        },
        contents: prompt,
      });

      const aiResult = JSON.parse(response.text || '{}');

      // Save to Firebase
      const docRef = await db.collection('simulations').add({
        ...simulation,
        results: aiResult,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });

      const doc = await docRef.get();
      const savedSimulation = {
        id: doc.id,
        ...doc.data()
      };

      return res.json(savedSimulation);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}