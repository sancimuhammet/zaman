// Vercel API endpoint for specific simulation
import type { VercelRequest, VercelResponse } from '@vercel/node';
import admin from 'firebase-admin';

// Firebase Admin initialization
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(),
    projectId: process.env.FIREBASE_PROJECT_ID || 'zaman-9903a'
  });
}

const db = admin.firestore();

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method === 'GET') {
    try {
      const { id } = req.query;
      
      if (!id || typeof id !== 'string') {
        return res.status(400).json({ error: 'Invalid simulation ID' });
      }

      const doc = await db.collection('simulations').doc(id).get();
      
      if (!doc.exists) {
        return res.status(404).json({ error: 'Simulation not found' });
      }

      const simulation = {
        id: doc.id,
        ...doc.data()
      };

      return res.json(simulation);
    } catch (error) {
      console.error('API Error:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  }

  res.status(405).json({ error: 'Method not allowed' });
}