# GitHub'a Yükleme Rehberi

## Yöntem 1: Replit'te Version Control Bulma

### Replit'te Git Panel Konumları:
1. **Sol kenar çubuğunda** Git ikonu (dallanmış çizgi simgesi)
2. **Üst menüde** "Version Control" 
3. **Files panelinin altında** "Source Control" sekmesi

### Bulamıyorsanız:
1. Replit'te **Ctrl+Shift+P** (veya Cmd+Shift+P Mac'te)
2. "Git" yazın ve seçenekleri görün
3. "Connect to GitHub" seçin

## Yöntem 2: Manuel GitHub Repository Oluşturma

### Adım 1: GitHub'da Repository Oluştur
1. https://github.com/sancimuhammet adresine git
2. Yeşil "New" butonuna tık
3. Repository name: `teksanbil-hayat-simulatoru`
4. Public seç
5. "Create repository" tık

### Adım 2: Dosyaları Yükle
1. "uploading an existing file" linkine tık
2. Replit'ten dosyaları seç ve sürükle
3. Commit message yaz
4. "Commit new files" tık

## Yöntem 3: Zip İndirme (En Kolay)

### Replit'te:
1. Sol üst köşede proje adına tık
2. "Download as zip" seç
3. Bilgisayarına indir
4. GitHub'da "Upload files" ile yükle

## Hangi dosyalar yüklenecek:
- ✅ client/ (Frontend kodu)
- ✅ server/ (Backend kodu)  
- ✅ shared/ (Ortak şema)
- ✅ package.json
- ✅ README.md
- ❌ node_modules (otomatik hariç)
- ❌ .git (gerek yok)