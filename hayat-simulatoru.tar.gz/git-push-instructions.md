# Git Push Talimatları

## Version Control Panel'de yapacaklar:

1. **Initialize Repository** (zaten yapıldı ✅)

2. **Stage Changes:**
   - "+" butonuna tık (tüm dosyaları stage et)
   - Veya dosya dosya seçerek stage et

3. **Commit:**
   - Commit message yaz: "İlk commit: Hayat Simülatörü"
   - "✓" (checkmark) butonuna tık

4. **GitHub Repository Bağla:**
   - "Publish to GitHub" butonu
   - Repository name: `teksanbil-hayat-simulatoru`
   - Public/Private seç
   - "Publish" tık

## Alternatif: Manuel Remote Ekleme
Eğer "Publish to GitHub" yoksa:
- "..." menüsünden "Add Remote"
- URL: `https://github.com/sancimuhammet/teksanbil-hayat-simulatoru.git`
- Name: `origin`
- "Push" butonuna tık

## Push edildikten sonra:
✅ Repository: github.com/sancimuhammet/teksanbil-hayat-simulatoru
✅ Tüm kod GitHub'da
✅ Deploy için hazır